#!/bin/bash

# AUTOMATED BACKUP SCRIPT

echo "       AUTOMATED BACKUP SCRIPT"
echo "======================================"

# Ask for source directory
read -p "Enter directory to backup: " SOURCE

# Validate source directory
if [ ! -d "$SOURCE" ]; then
    echo "Error: Source directory does not exist!"
    exit 1
fi

# Ask for backup destination
read -p "Enter backup destination: " DEST

# Create destination if it doesn't exist
mkdir -p "$DEST"

# Backup type selection
echo "Backup Type:"
echo "1. Simple copy"
echo "2. Compressed archive (tar.gz)"
read -p "Enter choice: " TYPE

# Timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BASENAME=$(basename "$SOURCE")

START=$(date +%s)

echo " Starting backup..."
echo " Source: $SOURCE"
echo " Destination: $DEST"

#  Perform Backup
if [ "$TYPE" = "1" ]; then
    BACKUP_NAME="backup_${BASENAME}_${TIMESTAMP}"
    cp -r "$SOURCE" "$DEST/$BACKUP_NAME"

elif [ "$TYPE" = "2" ]; then

    BACKUP_NAME="backup_${BASENAME}_${TIMESTAMP}.tar.gz"
    tar -czf "$DEST/$BACKUP_NAME" -C "$(dirname "$SOURCE")" "$BASENAME"

else
    echo "Invalid choice!"
    exit 1
fi

END=$(date +%s)
DURATION=$((END - START))

#  Verification
if [ -e "$DEST/$BACKUP_NAME" ]; then
    echo ""
    echo "Backup completed successfully!"
    echo ""
    echo "Backup Details:"
    echo "File: $BACKUP_NAME"
    echo "Location: $DEST"
    SIZE=$(du -sh "$DEST/$BACKUP_NAME")
    echo "Size: $SIZE"
    echo "Time taken: $DURATION seconds"
else
    echo "Backup failed!"
    exit 1
fi


#  Keep only last 5 backups (Rotation)
echo ""
echo "** Performing backup rotation (keeping last 5)..."
ls -t "$DEST"/backup_* 2>/dev/null | tail -n +6 | xargs -r rm --

#  Log file
LOGFILE="$DEST/backup.log"
echo "$(date) - Backup created: $BACKUP_NAME | Size: $SIZE | Duration: ${DURATION}s" >> "$LOGFILE"
echo "** Backup logged to $LOGFILE"

#Email notification
echo ""
read -p "enter the email for notification : " mail
echo " backup notification sent to email $mail"