#!/bin/bash

# Log File Analyzer

# 1. Check argument provided
if [ $# -ne 1 ]; then
    echo "Usage: $0 <logfile>"
    exit 1
fi

LOGFILE=$1

blue='\033[1;34m'

# 2. Check if file exists
if [ ! -f "$LOGFILE" ]; then
    echo "Error: File does not exist!"
    exit 1
fi

# 3. Check if file is empty
if [ ! -s "$LOGFILE" ]; then
    echo "Error: Log file is empty!"
    exit 1
fi

echo -e "${blue}"     #for coloring
echo "        LOG FILE ANALYSIS"
echo "==================================="
echo "Log File: $LOGFILE"

# 4. Total entries
TOTAL=$(wc -l  < "$LOGFILE")
echo "Total Entries: $TOTAL"

# 5. Unique IP addresses
echo ""
echo "Unique IP Addresses are:"
IPS=$(awk '{print $1}' "$LOGFILE" | sort | uniq)
echo "$IPS"

# 6. Status Code Summary
echo ""
echo "Status Code Summary:"
awk '{print $NF}' "$LOGFILE" | sort | uniq -c | while read count code
do
    echo " $code: $count requests"
done

# 7. Most Frequently Accessed Page
echo ""
echo "Most Frequently Accessed Page:"
awk -F\" '{print $2}' "$LOGFILE" | awk '{print $2}' | \
sort | uniq -c | sort -nr | head -1 | \
awk '{print $2 " - " $1 " requests"}'

# 8. Top 3 IP addresses
echo ""
echo "Top 3 IP Addresses:"
awk '{print $1}' "$LOGFILE" | sort | uniq -c | \
sort -nr | head -3 | \
awk '{print NR ". " $2 " - " $1 " requests"}'

# 9. detect security threats (multiple 403)
echo ""
echo "Security Alert (Multiple 403 Attempts):"
awk '$NF==403 {print $1}' "$LOGFILE" | sort | uniq -c | \
awk '$1 > 1 {print "Potential threat from IP:", $2, "-", $1, "403 errors"}'

# 10. Generate CSV Report
echo ""
echo "Generating CSV report: report-q3.csv"

echo "IP,Requests" > report-q3.csv
awk '{print $1}' "$LOGFILE" | sort | uniq -c | \
awk '{print $2 "," $1}' >> report.csv

echo "CSV report generated successfully!"