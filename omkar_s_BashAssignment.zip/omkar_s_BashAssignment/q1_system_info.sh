#!/bin/bash

#information capturing
USERNAME=$(whoami)     #Current username
HOSTNAME=$(hostname)    #Hostname
DATE_TIME=$(date "+%Y-%m-%d %H:%M:%S") #Current date and time
OS=$(uname -s)            #Operating system name
CURRENT_DIR=$(pwd)        #Current working directory
HOME_DIR=$HOME             #Home directory 
USERS_ONLINE=$(who | wc -l)    #Number of users logged in
UPTIME=$(uptime -p)            #System uptime
DISK_USAGE=$(df -h / | awk 'NR==2 {print $3 " used of " $2 " (" $5 ")"}')    #disk usage 
MEMORY_USAGE=$(free -h | awk '/Mem:/ {print $3 " used of " $2}')             #memory usage

# ANSI Colors
BLUE='\033[1;34m'
GREEN='\033[1;32m'
RESET='\033[0m'

# Display in table fprmat
echo -e "${BLUE}|============================================|"
echo -e "${BLUE}|${GREEN}        SYSTEM INFORMATION DISPLAY          ${BLUE}|"
echo -e "${BLUE}|============================================|"
echo -e "${BLUE}| ${GREEN}Username       :${RESET} $USERNAME                  ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Hostname       :${RESET} $HOSTNAME                      ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Date & Time    :${RESET} $DATE_TIME       ${BLUE}|"
echo -e "${BLUE}| ${GREEN}OS             :${RESET} $OS                     ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Current Dir    :${RESET} $CURRENT_DIR  ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Home Dir       :${RESET} $HOME_DIR            ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Users Online   :${RESET} $USERS_ONLINE                         ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Uptime         :${RESET} $UPTIME     ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Disk Usage     :${RESET} $DISK_USAGE     ${BLUE}|"
echo -e "${BLUE}| ${GREEN}Memory Usage   :${RESET} $MEMORY_USAGE       ${BLUE}|"
echo -e "${BLUE}|============================================|${RESET}"