#!/bin/bash

# File & Directory Manager

while true
do
    echo "       FILE & DIRECTORY MANAGER"
    echo "===================================="
    echo "1. List files in current directory"
    echo "2. Create a new directory"
    echo "3. Create a new file"
    echo "4. Delete a file"
    echo "5. Rename a file"
    echo "6. Search for a file"
    echo "7. Count files and directories"
    echo "8. View file permissions "
    echo "9. Copy a file "
    echo "10. Exit"
    echo "===================================="
    read -p "Enter your choice: " choice
 #using case statement
    case $choice in
       
        1) echo "Listing files in current directory"   #List files
           ls -lh ;;

        2) read -p "Enter directory name: " dirname   #Create a new directory
            if [ -d "$dirname" ]; then
                echo "Directory already exists!"
            else
                mkdir "$dirname"
                echo "Directory created successfully."
            fi ;;

        3) read -p "Enter file name: " filename   #Create a new file
             if [ -f "$filename" ]; then
                echo "File already exists!"
             else
                touch "$filename"
                echo "File created successfully."
             fi ;;

        4) read -p "Enter file name to delete: " filename   #Delete a file
            if [ -f "$filename" ]; then
                read -p "Are you sure you want to delete $filename? (y/n): " option
                if [ "$option" = "y" ]; then
                    rm "$filename"
                    echo "File deleted successfully."
                else
                    echo "Deletion cancelled."
                fi
            else
                echo "File does not exist!"
            fi ;;

        5)read -p "Enter old file name: " oldname   #renaming file
            if [ -f "$oldname" ]; then
                read -p "Enter new file name: " newname
                mv "$oldname" "$newname"
                echo "File renamed successfully."
            else
                echo "File does not exist!"
            fi ;;

        6) read -p "Enter file name or pattern to search: " pattern   #searching file
            echo "Searching..."
            if [ -f $pattern ]; then
              find . -name "$pattern" 
              echo "file found"
            else
              echo "file not found" 
            fi ;;

        7)  files=$(find . -type f | wc -l)    #list number of files and directory
            dirs=$(find . -type d | wc -l)
            echo "Number of files: $files"
            echo "Number of directories: $dirs" ;;

        8)  read -p "Enter file name to view permissions: " filename   #viewing file
            if [ -e "$filename" ]; then
                ls -l "$filename"
            else
                echo "File does not exist!"
            fi ;;

        9) read -p "Enter source file name: " source    #coping file
            if [ -f "$source" ]; then
                read -p "Enter destination file name: " dest
                cp "$source" "$dest"
                echo "File copied successfully."
            else
                echo "Source file does not exist!"
            fi ;;

        10) echo " program exited"   #to exit
            break ;;

        *)                                           #for invalid key
            echo "Invalid choice! Please select a valid option." ;;
           

    esac

    echo ""
    read -p "press enter "
done